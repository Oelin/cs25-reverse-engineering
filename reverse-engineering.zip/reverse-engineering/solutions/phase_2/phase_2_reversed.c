int phase_2(char *input) {

        int array[6];
	int a = 1;
	int b = 0;

	sscanf(input, "%d %d %d %d %d %d", array, array + 1, array + 2, array + 3, array + 4, array + 5);
        
	if (array[0] < 0) {
		explode_bomb();
	}

	for (int i = 0; i <= 6; i ++) {

		b = (a ++) + array[i];

		if (b != array[i + 1]) {
			explode_bomb();
		}
	}
}
