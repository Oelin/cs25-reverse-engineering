array = bytes([0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 6, 0, 0, 0, 1, 0, 0, 0, 12, 0, 0, 0, 16, 0, 0, 0, 9, 0, 0, 0, 3, 0, 0, 0, 4, 0, 0, 0, 7, 0, 0, 0, 14, 0, 0, 0, 5, 0, 0, 0, 11, 0, 0, 0, 8, 0, 0, 0, 15, 0, 0, 0, 13])


def phase_5(input):

        string_length = len(input)

        if string_length != 6:
                return 'Explode'

        string_current = 0
        ecx = 0

        while string_current < string_length:

                current_character = ord(input[string_current])
                current_character &= 0xf

                ecx += int(array[current_character * 4 : (current_character + 1) * 4].hex(), 16)
                string_current += 1

                print(current_character, ecx)

        if ecx == 0x48:
                return 'Defuse'

        else:
                return 'Explode'
