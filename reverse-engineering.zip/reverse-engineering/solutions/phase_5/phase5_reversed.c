int phase_5(char *input) {

        int rbx = input;
        int string_length_output = string_length(input);

        if (string_length_output != 0x6) {
                explode_bomb();
        }

        rax = rbx; // Start of string.
        rdi = input + 0x6 // End of string.
        ecx = 0;

        while (1) {
                edx = rax;
                edx &= 0xf;
                ecx += *(rdx * 4 + 0x402660);
                rax += 1;

                if (rax == rdi) {
                        break;
                }
        }

        if (ecx != 0x48) {
                explode_bomb();
        }

        return 0;
}
