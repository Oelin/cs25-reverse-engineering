int fun7(int *param_1,int param_2) {

	int iVar1;


	if (param_1 == (int *)0x0) {
		iVar1 = -1;
	}

	else if (param_2 < *param_1) {
		iVar1 = fun7(*(int **)(param_1 + 2),param_2);
		iVar1 = iVar1 * 2;
	}
  
	else {
		iVar1 = 0;
    
		if (*param_1 != param_2) {
			iVar1 = fun7(*(int **)(param_1 + 4),param_2);
			iVar1 = iVar1 * 2 + 1;
		}
	}

	return iVar1;


void secret_phase(void) {

	int iVar1;
	char *__nptr;
	long lVar2;
  
	__nptr = read_line();
	lVar2 = strtol(__nptr,(char **)0x0,10);
  
	if (1000 < (int)lVar2 - 1U) {
		explode_bomb();
	}
  
	iVar1 = fun7((int *)n1,(int)lVar2);
  
	if (iVar1 != 4) {
		explode_bomb();
	}
  
	puts("Wow! You\'ve defused the secret stage!");
	phase_defused();
	return;
}
