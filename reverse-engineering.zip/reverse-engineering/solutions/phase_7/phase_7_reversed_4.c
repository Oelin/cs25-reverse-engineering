#define n1_pointer 0x604100 


int fun7(int *x, int y) {

	if (x == NULL) {
		return -1;
	}

	else if (*x > y) {
		return 2 * fun7(x + 2*sizeof(int), y);
	}
  
	else if (*x != y) {
		return 1 + 2 * fun7(x + 4*sizeof(int), y);
	}

	return 0;
}


void secret_phase() {

	unsigned int base = 10;
	unsigned int number = (unsigned int) strtol(read_line(), 0, base);
  
	if (number > 1001) {
		explode_bomb();
	}
  
	int fun7_output = fun7(n1_pointer, number);
  
	if (fun7_output != 4) {
		explode_bomb();
	}
  
	puts("Wow! You\'ve defused the secret stage!");
	phase_defused();
	return;
}
