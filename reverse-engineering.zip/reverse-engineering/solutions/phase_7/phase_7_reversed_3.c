int fun7(int *x, int y) {

	if (x == NULL) {
		return -1;
	}

	else if (*x > y) {
		return 2 * fun7(*(x + 2), y);
	}
  
	else if (*x != y) {
		return 1 + 2 * fun7(*(x + 4), y);
	}

	return 0;
}


void secret_phase() {

	unsigned int base = 10;
	unsigned int number = (unsigned int) strtol(read_line(), 0, base);
  
	if (number > 1001) {
		explode_bomb();
	}
  
	int fun7_output = fun7((int *) n1, number);
  
	if (fun7_output != 4) {
		explode_bomb();
	}
  
	puts("Wow! You\'ve defused the secret stage!");
	phase_defused();
	return;
}
