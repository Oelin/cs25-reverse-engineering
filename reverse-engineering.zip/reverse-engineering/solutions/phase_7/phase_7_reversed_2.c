int fun7(int *param_1, int base) {

	int iVar1;


	if (param_1 == (int *)0x0) {
		iVar1 = -1;
	}

	else if (param_2 < *param_1) {
		iVar1 = fun7(*(int **)(param_1 + 2), base);
		iVar1 = iVar1 * 2;
	}
  
	else {
		iVar1 = 0;
    
		if (*param_1 != base) {
			iVar1 = fun7(*(int **)(param_1 + 4), base);
			iVar1 = iVar1 * 2 + 1;
		}
	}

	return iVar1;


void secret_phase(void) {

	unsigned int base = 10;
	unsigned int number = (unsigned int) strtol(read_line(), 0, base);
  
	if (number > 1001) {
		explode_bomb();
	}
  
	int fun7_output = fun7((int *) n1, number);
  
	if (fun7_output != 4) {
		explode_bomb();
	}
  
	puts("Wow! You\'ve defused the secret stage!");
	phase_defused();
	return;
}
