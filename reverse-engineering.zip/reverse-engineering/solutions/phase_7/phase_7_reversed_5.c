#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct node_t {
	long long value;
	struct node_t *node1;
	struct node_t *node2;
	long long zero;
};


struct node_t *n01;
struct node_t *n21;
struct node_t *n22;
struct node_t *n31;
struct node_t *n32;
struct node_t *n33;
struct node_t *n34;
struct node_t *n41;
struct node_t *n42;
struct node_t *n43;
struct node_t *n44;
struct node_t *n45;
struct node_t *n46;
struct node_t *n47;
struct node_t *n48;


int fun7(struct node_t *, int);
int secret_phase(char *);
int explode_bomb(void);


int main(int _, char *argv[]) {

	// Create a symmetric binary tree of depth 3...

	n01 = calloc(0, sizeof(struct node_t));
	n21 = calloc(0, sizeof(struct node_t));
	n22 = calloc(0, sizeof(struct node_t));
	n31 = calloc(0, sizeof(struct node_t));
	n32 = calloc(0, sizeof(struct node_t));
	n33 = calloc(0, sizeof(struct node_t));
	n34 = calloc(0, sizeof(struct node_t));
	n41 = calloc(0, sizeof(struct node_t));
	n42 = calloc(0, sizeof(struct node_t));
	n43 = calloc(0, sizeof(struct node_t));
	n44 = calloc(0, sizeof(struct node_t));
	n45 = calloc(0, sizeof(struct node_t));
	n46 = calloc(0, sizeof(struct node_t));
	n47 = calloc(0, sizeof(struct node_t));
	n48 = calloc(0, sizeof(struct node_t));

	n01->value = 0x0000000000000024; // 36
	n01->node1 = n21;
	n01->node2 = n22;

	n21->value = 0x0000000000000008; // 8
	n21->node1 = n31;
	n21->node2 = n32;

	n22->value = 0x0000000000000032; // 50
	n22->node1 = n33;
	n22->node2 = n34;

	n31->value = 0x0000000000000006; // 6
	n31->node1 = n41;
	n31->node2 = n42;

	n32->value = 0x0000000000000016; // 22
	n32->node1 = n43;
	n32->node2 = n44;

	n33->value = 0x000000000000002d; // 45
	n33->node1 = n45;
	n33->node2 = n46;

	n34->value = 0x000000000000006b; // 107
	n34->node1 = n47;
	n34->node2 = n48;
	
	n41->value = 0x0000000000000001; // 1
	n42->value = 0x0000000000000007; // 7
	n43->value = 0x0000000000000014; // 20
	n44->value = 0x0000000000000023; // 35
	n45->value = 0x0000000000000028; // 40
	n46->value = 0x000000000000002f; // 47
	n47->value = 0x0000000000000063; // 99
	n48->value = 0x00000000000003e9; // 1001


	// User input...

	char input[8];

	sscanf(argv[1], "%4s", input);
	secret_phase(input);

	return 0;
}


int secret_phase(char *input) {

	unsigned int number = (unsigned int) strtol(input, (char **) 0, 10);

	if (number > 1001) {
		explode_bomb();
	}

	int fun7_output = fun7(n01, number);

	printf("fun7 output: %d\n", fun7_output);

	if (fun7_output != 4) {
		explode_bomb();
	}

	puts("Bomb defused!!!");
	return 0;
}

/*
void which_node(struct node_t *node) {
	char *id;

	if (node == n01) { id = "node01"; }
	else if (node == n21) { id = "node21"; }
	else if (node == n22) { id = "node22"; }
	else if (node == n31) { id = "node31"; }
	else if (node == n32) { id = "node32"; }
	else if (node == n33) { id = "node33"; }
	else if (node == n34) { id = "node34"; }
	else if (node == n41) { id = "node41 (leaf)"; }
	else if (node == n42) { id = "node42 (leaf)"; }
	else if (node == n43) { id = "node43 (leaf)"; }
	else if (node == n44) { id = "node44 (leaf)"; }
	else if (node == n45) { id = "node45 (leaf)"; }
	else if (node == n46) { id = "node46 (leaf)"; }
	else if (node == n47) { id = "node47 (leaf)"; }
	else if (node == n48) { id = "node48 (leaf)"; }
	else if (node == 0x0) { id = "NULL"; }
	else { id = "unknown"; }

	printf("[*] At node %s with value %lu\n", id, node ? node->value : 0);
}
*/


int fun7(struct node_t *node, int x) {
	//which_node(node);

	if (node == (struct node_t *) 0) {
		return -1;
	}

	else if (node->value > x) {
		return 2 * fun7(node->node1, x);
	}

	else if (node->value != x) {
		return 2 * fun7(node->node2, x) + 1;
	}

	return 0;
}


int explode_bomb() {
	puts("Bomb exploded!");
	exit(1);
}
