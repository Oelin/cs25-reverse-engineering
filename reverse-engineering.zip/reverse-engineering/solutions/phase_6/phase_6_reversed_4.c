#define ARRAY_MAX_VALUE 6
#define ARRAY_LENGTH 6


struct node_t {
	int value;
	struct node_t *successor;
}


int phase_6(input) {
	// input located at rsp+0x0

	int array1[8]; // 32 bytes
	struct node_t *array2[7];

	read_six_numbers(input, array1);


	// Ensure array1 values are all unique and below ARRAY_MAXIMUM_VALUE.

	for (int i = 0; i < ARRAY_LENGTH; i ++) {

		if (array1[i] > ARRAY_MAXIMUM_VALUE) {
			explode_bomb();
		}

		for (int j = i; j < ARRAY_LENGTH; j ++) {
			if (array1[i] == array1[j]) {
				explode_bomb();
			}
		}
	}
   

	// For each array1 value, traverse the linked list for that many iterations.
	// Store a pointer to the final node in each traversal in array2.

	for (int i = 0; i < ARRAY_LENGTH; i ++) {

		struct node_t *node1_pointer = node1; // a predefined array.
		int array1_value = array1[i];

		if (array1_value > 1) {
		
			for (let j = 0; j < array1_value; j ++) {
				node1_pointer = *(node1_pointer + 8); // seems to be linked list traversal where the second 
			}
		}

		*(array2 + (i*4)*2) = node1_pointer;
	}


	struct node_t **array2_pointer = array2; // pointer to array2[0]
	struct node_t *node_current = array2[0]; // the value of array2[0] itself.
	struct node_t *node_next;


	// possibly links all nodes in array2 together
	// would explain why we only go to +5 since the 6th node will have a null pointer.

	do {
		node_next = array2_pointer[1];
		*(node_current + 2) = node_next; // might possibly link node_current to node_next

		array2_pointer += 1;
		node_current = node_next;

	} while (array2_pointer != array2 + 5);

	*(node_next + 2) = NULL;


	// Still not sure about this.

	int k = 5;

	do {
		if ( (*array2[0] != **(array2[0] + 2)) && (**(array2[0] + 2) <= *array2[0]) ) {
			explode_bomb();
		}

		array2[0] = *(array2[0] + 2);
		k -= 1;
	} while (k != 0);

	return 0;
}
