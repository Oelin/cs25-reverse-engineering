int phase_6(input) {

   <+24 - +104>

   eax = 0;
   rsi = rsp;
   read_six_numbers();


   for (int i = 0; i < ARRAY_LENGTH; i ++) {

       if (array1[i] > ARRAY_MAXIMUM_VALUE) {
           explode_bomb();
       }

       for (int j = i; j < ARRAY_LENGTH; j ++) {
           if (array1[i] == array1[j]) {
	       explode_bomb();
           }
       }
   }
   
   <+106 - +157>

   esi = 0;

   do {
       ecx = *(rsp + rsi);
       eax = 1;

       if (ecx > 1) {
           do {
               rdx = *(rdx + 8);
	       eax += 1;
	   } while (eax != ecx);
       }

       *(rsp + rsi*2 + 32) = rdx;
       rsi += 4;
   } while (esi != 24);


   <+159 - +174>

   rbx = *(rsp + 32);
   rax = rsp + 32;
   rsi = rsp + 72;
   rcx = rbx;

   <+177 - +195>

   do {
       rdx = *(rax + 8);
       *(rcx + 8) = rdx;

       rax += 8;
       rcx = rdx;
   } while (rax != rsi);
	
   <+197 - +205>

   *(rdx + 8) = 0;
   ebp = 5;

   <+210 - +232>

   do {
       rax = *(rbx + 8);
       eax = *rax

       if (*rbx > eax) {
           explode_bomb();
       }

       rbx = *(rbx + 8);
       ebp --;
   } while (ebp > 0);


   <+234 - +265>
   return;
}
