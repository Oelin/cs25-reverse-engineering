#define ARRAY_MAX_VALUE 6
#define ARRAY_LENGTH 6


struct node_t {
	int value;
	struct node_t *successor;
}


int phase_6(input) {
	// input located at rsp+0x0

	int array1[8]; // 32 bytes
	struct node_t *array2[7];

	read_six_numbers(input, array1);


	// Ensure array1 values are all unique and below ARRAY_MAXIMUM_VALUE.

	for (int i = 0; i < ARRAY_LENGTH; i ++) {

		if (array1[i] > ARRAY_MAXIMUM_VALUE) {
			explode_bomb();
		}

		for (int j = i; j < ARRAY_LENGTH; j ++) {
			if (array1[i] == array1[j]) {
				explode_bomb();
			}
		}
	}
   

	// For each array1 value, traverse the linked list for that many iterations.
	// Store a pointer to the final node in each traversal in array2.

	for (int i = 0; i < ARRAY_LENGTH; i ++) {

		struct node_t *node1_pointer = node1; // a predefined array.
		int array1_value = array1[i];

		if (array1_value > 1) {
		
			for (let j = 0; j < array1_value; j ++) {
				node1_pointer = *(node1_pointer + 8); // seems to be linked list traversal where the second 
			}
		}

		*(array2 + (i*4)*2) = node1_pointer;
	}


	rbx = array2;
	rbx = *(rsp + 32);
	rax = rsp + 32;
	rsi = rsp + 72;
	rcx = rbx;

	do {
		rdx = *(rax + 8);
		*(rcx + 8) = rdx;

		rax += 8;
		rcx = rdx;
	} while (rax != rsi);
	
   

	*(rdx + 8) = 0;
	ebp = 5;

	do {
		rax = *(rbx + 8);
		eax = *rax

		if (*rbx > eax) {
			explode_bomb();
		}

		rbx = *(rbx + 8);
		ebp --;
	} while (ebp > 0);

   return 0;
}
