int phase_4(char *input) {

        unsigned int a;
        unsigned int b;

        int number_of_matches = sscanf(input, "%d %d", a, b);

        if (number_of_matches != 2) {
                explode_bomb();
        }

        if (a > 0xe) {
                explode_bomb();
        }

        int func4_output = func4(0xe, 0x0, a);

        if (func4_output != 0x7) {
                explode_bomb();
        }

        if (b != 0x7) {
                explode_bomb();
        }

        return 0;
}
